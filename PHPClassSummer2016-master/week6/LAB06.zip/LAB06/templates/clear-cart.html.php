<form action="?" method="post">
    <p>
        <input type="submit" name="action" value="Empty cart" class="waves-effect red waves-light btn-large" style="width:200px;">
    </p>
</form>