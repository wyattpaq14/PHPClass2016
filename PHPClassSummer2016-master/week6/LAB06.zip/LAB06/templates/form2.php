<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="row">
    <div class="input-field col s6">
        <input id="first_name" type="text" name="fname">
        <label for="first_name">First Name</label>
    </div>
    <div class="input-field col s6">
        <input id="last_name" type="text" name="lname">
        <label for="last_name">Last Name</label>
    </div>
</div>


